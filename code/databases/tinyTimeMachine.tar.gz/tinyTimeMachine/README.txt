360 images downloaded from Google Street View Time Machine.

The dataset is not supposed to be seriously used for place recognition, is only a tiny sample of the Tokyo Time Machine dataset. The purpose of this tiny sample is just for people to check if they configured the NetVLAD library correctly.

See our project page for more information:
http://www.di.ens.fr/willow/research/netvlad/

To try it out:
- Download our code from the project page, set it up (install dependencies)
- Set the variable paths.dsetRootTokyoTM in localPaths.m to point to the folder this file resides in
- Run the tiny dummy example from the end of demo.m
